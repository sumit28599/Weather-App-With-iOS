//
//  WeatherAppCollectionViewCell.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//

import UIKit

class WeatherAppCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var forecastView: UIView!
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var timelbl: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    
}
