//
//  NextSevenDaysCollectionViewCell.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//

import UIKit

class NextSevenDaysCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var daysAndDate: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    
}
