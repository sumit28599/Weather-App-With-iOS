//
//  NextSevenDaysViewController.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//

import UIKit

class NextSevenDaysViewController: UIViewController {
    @IBOutlet weak var NextSevenDaysCollectionView: UICollectionView!
 
    var dayDataArray: [DaysData] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NextSevenDaysCollectionView.delegate = self
        NextSevenDaysCollectionView.dataSource = self
        // Do any additional setup after loading the view.
        getDataFromAPI()
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func getDataFromAPI() {
        let apiURLString = "https://api.weatherapi.com/v1/forecast.json?key=20cbed94eb3249a8896170136232705&q=London&days=7&aqi=no&alerts=no"
        guard let url = URL(string: apiURLString) else {
            print(" failed to get URL!")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { [self] data, response, error in
            if error == nil, let responseData = data {
                do {
                    let jsonData = try JSONDecoder().decode(Root.self, from: responseData)
                    
                    let Days = jsonData.forecast.forecastday.first?.date
                    for _ in Days! {
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
                            let calendar = Calendar.current
                            let DaysDataVal = calendar.component
                        let DaysDataValue = DaysData(date: "\(String(describing: DaysDataVal))")
                            dayDataArray.append(DaysDataValue)
                    }
                    DispatchQueue.main.async {
                        self.NextSevenDaysCollectionView.reloadData()
                    }
                    
                    
                }
                catch let error {
                    print(error.localizedDescription)
                }
                
            }
            else{
                print("No data found")
            }
        }.resume()
    }

}

extension NextSevenDaysViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dayDataArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NextSevenDaysCollectionViewCell", for: indexPath) as! NextSevenDaysCollectionViewCell

        cell.daysAndDate.text = dayDataArray[indexPath.row].date
        return cell
    
  }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width
        return CGSize(width: width/4 - 20, height: width/4 - 20)
    }
}



