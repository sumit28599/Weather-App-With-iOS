//
//  WeatherAppViewController.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//

import UIKit

class WeatherAppViewController: UIViewController {

    
    var arrayList :[WeatherList] =  []
    var models: [Forecastday] = []
    var currentSelected : Int?
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var weatherName: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    @IBOutlet weak var uvLabel: UILabel!
    @IBOutlet weak var pressure: UILabel!
    @IBOutlet weak var feelslike: UILabel!
        @IBOutlet weak var datelbl: UILabel!
        @IBOutlet weak var countryName: UILabel!
        @IBOutlet weak var WeatherImage: UIImageView!
    @IBOutlet weak var WeatherAppCollectionView: UICollectionView!
    @IBOutlet weak var WeatherView: UIView!
  //  @IBOutlet weak var nextSevendaysBtn: UIButton!
    @IBOutlet weak var windView: UIView!
    @IBOutlet weak var feelsLikeView: UIView!
    @IBOutlet weak var uvIndexView: UIView!
    @IBOutlet weak var presureView: UIView!


    @IBOutlet weak var wind: UILabel!
    var timeArray = ["12:00","14:00","16:00","18:00","20:00","22:00","00:00","02:00","04:00","06:00","08:00"]
    var tempArray = ["26°","25°","26°","25°","28°","27°","21°","19°","21°","23°","23°"]
    var city = ""
    var weather = ""
    var temp = ""
    var weatherImg = ""
    var uvData = ""

    var date = ""
 //   var day = ""
//    var humidity = ""
//   var windKph = ""
    var time = ""

    var apiWeatherValue:WeatherList? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        WeatherAppCollectionView.delegate = self
        WeatherAppCollectionView.dataSource = self
        getDataFromAPI()
        WeatherView.layer.cornerRadius = 14
        setBorderView()
        
    }

    func setBorderView() {
        windView.setBorderToView()
        feelsLikeView.setBorderToView()
        uvIndexView.setBorderToView()
        presureView.setBorderToView()
    }
    func getDataFromAPI() {
        let apiURLString = "https://api.weatherapi.com/v1/forecast.json?key=20cbed94eb3249a8896170136232705&q=London&days=1&aqi=no&alerts=no"
        guard let url = URL(string: apiURLString) else {
            print(" failed to get URL!")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { [self] data, response, error in
            if error == nil, let responseData = data {
                do {
                    let jsonData = try JSONDecoder().decode(Root.self, from: responseData)
                    let image = "https:\(jsonData.current.condition.icon.rawValue)"
                    let weather = jsonData.current.condition.text.rawValue
                    let country = "\(jsonData.location.country),\(jsonData.location.name)"
                //    let region = jsonData.location.region
                    print("country========\(country)°")
                    let city = jsonData.location.name
                    let temprature = "\(jsonData.current.tempC)"
                    let uvIndex = "\(jsonData.current.uv)"
                    let date = jsonData.forecast.forecastday[0].date
                    let time = "\(jsonData.forecast.forecastday[0].hour[0].time)"
                    print("kjhgfdmnbvc===\(time)")
//                    let humidity = "\(jsonData.current.humidity)"
                  //  let windKph = "45" //"\(jsonData.current.windKph)"
                    
                    apiWeatherValue = WeatherList(weather: weather, country: country,city: city, temprature: temprature, WeatherImage: image, uvIndex: uvIndex,date: date, time: time)
                    DispatchQueue.main.async { [self] in
                        cityName.text = country
                   //     regionlbl.text = region
                        weatherName.text = weather
                        tempreture.text = "\(temprature)°"
                        print("time========\(time)°")
                       uvLabel.text = uvIndex
                        datelbl.text = date
                   //     humidityLbl.text = "\(humidity)%"
                       // weatherName.text = weather
                        let apiURLStrings = image
                        WeatherImage.downloaded(from: apiURLStrings)
                        
                    }
                    
                }
                catch let error {
                    print(error.localizedDescription)
                }
                
            }
            else{
                print("No data found")
            }
        }.resume()
    }

    @IBAction func nextSevenDaysutton(_ sender: Any) {
        let mainS = UIStoryboard(name: "Main", bundle: nil)
        let vc = mainS.instantiateViewController(withIdentifier: "NextSevenDaysViewController") as! NextSevenDaysViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
}


extension WeatherAppViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  timeArray.count //arrayList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WeatherAppCollectionViewCell", for: indexPath) as! WeatherAppCollectionViewCell

        if currentSelected != nil && currentSelected == indexPath.row
               {
           // UIColor(named: "#365EF4").
            cell.forecastView.backgroundColor = UIColor.systemBlue
           
               }else{
                   cell.forecastView.backgroundColor = UIColor.white
               }
       
        cell.forecastView.layer.cornerRadius = 12
        cell.forecastView.layer.masksToBounds = true
        cell.forecastView.layer.borderColor = UIColor.lightGray.cgColor
        cell.forecastView.layer.borderWidth = 0.5
        cell.timelbl.text = timeArray[indexPath.row]
        cell.tempreture.text = tempArray[indexPath.row]
        return cell
    
  }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width
        return CGSize(width: width/4 - 20, height: width/3 + 40)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentSelected = indexPath.row
        self.WeatherAppCollectionView.reloadItems(at: [indexPath])
    }
}



