//
//  DataModel.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//

import Foundation

struct WeatherList: Codable  {
    var weather: String
    var country: String
   // var region: String
    var city: String
    var temprature: String
    var WeatherImage: String
    var uvIndex:String
//    var sunrise: String
//    var sunset: String
   // var day : String
    var date: String
//    var humidity: String
//    var windKph: String
    var time:String
}
