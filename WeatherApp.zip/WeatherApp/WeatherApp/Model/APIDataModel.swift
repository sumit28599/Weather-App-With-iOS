//
//  APIDataModel.swift
//  WeatherApp
//
//  Created by apple on 07/09/23.
//


import Foundation

// MARK: - WeatherForcast
struct Root: Codable {
    let location: Location
    let current: Current
    let forecast: Forecast
}

// MARK: - Current
struct Current: Codable {
     let tempC: Int
     let tempF: Double
//    let isDay: Int
    let condition: Condition
    let precipMm, precipIn, humidity, cloud: Int
        let uv: Int
    enum CodingKeys: String, CodingKey {
        case tempC = "temp_c"
        case tempF = "temp_f"
        case condition
        case precipMm = "precip_mm"
        case precipIn = "precip_in"
        case humidity, cloud
          case uv
    }
}

// MARK: - Condition
struct Condition: Codable {
    let text: Text
    let icon: Icon
    let code: Int
}

enum Icon: String, Codable {
    case cdnWeatherapiCOMWeather64X64Day113PNG = "//cdn.weatherapi.com/weather/64x64/day/113.png"
    case cdnWeatherapiCOMWeather64X64Day116PNG = "//cdn.weatherapi.com/weather/64x64/day/116.png"
    case cdnWeatherapiCOMWeather64X64Night113PNG = "//cdn.weatherapi.com/weather/64x64/night/113.png"
    case cdnWeatherapiCOMWeather64X64Night119PNG = "//cdn.weatherapi.com/weather/64x64/night/119.png"
    case cdnWeatherapiCOMWeather64X64Night122PNG = "//cdn.weatherapi.com/weather/64x64/night/122.png"
}

enum Text: String, Codable {
    case clear = "Clear"
    case cloudy = "Cloudy"
    case overcast = "Overcast"
    case partlyCloudy = "Partly cloudy"
    case sunny = "Sunny"
}

// MARK: - Forecast
struct Forecast: Codable {
    let forecastday: [Forecastday]
    
}

// MARK: - Forecastday
struct Forecastday: Codable {
    let date: String
    let astro: Astro
    let hour: [Hour]
}

// MARK: - Astro
struct Astro: Codable {
    let sunrise, sunset, moonrise, moonset: String
    let moonPhase, moonIllumination: String
    let isMoonUp, isSunUp: Int

    enum CodingKeys: String, CodingKey {
        case sunrise, sunset, moonrise, moonset
        case moonPhase = "moon_phase"
        case moonIllumination = "moon_illumination"
        case isMoonUp = "is_moon_up"
        case isSunUp = "is_sun_up"
    }
}

// MARK: - Day
struct Day: Codable {
    let maxtempC, maxtempF, mintempC, mintempF: Double
    let avgtempC, avgtempF: Double
    let maxwindMph: Int
    let maxwindKph: Double
    let totalprecipMm, totalprecipIn, totalsnowCM, avgvisKM: Int
    let avgvisMiles, avghumidity, dailyWillItRain, dailyChanceOfRain: Int
    let dailyWillItSnow, dailyChanceOfSnow: Int
    let condition: Condition
    let uv: Int

    enum CodingKeys: String, CodingKey {
        case maxtempC = "maxtemp_c"
        case maxtempF = "maxtemp_f"
        case mintempC = "mintemp_c"
        case mintempF = "mintemp_f"
        case avgtempC = "avgtemp_c"
        case avgtempF = "avgtemp_f"
        case maxwindMph = "maxwind_mph"
        case maxwindKph = "maxwind_kph"
        case totalprecipMm = "totalprecip_mm"
        case totalprecipIn = "totalprecip_in"
        case totalsnowCM = "totalsnow_cm"
        case avgvisKM = "avgvis_km"
        case avgvisMiles = "avgvis_miles"
        case avghumidity
        case dailyWillItRain = "daily_will_it_rain"
        case dailyChanceOfRain = "daily_chance_of_rain"
        case dailyWillItSnow = "daily_will_it_snow"
        case dailyChanceOfSnow = "daily_chance_of_snow"
        case condition, uv
    }
}

// MARK: - Hour
struct Hour: Codable {
    let time: String
    let isDay: Int
    enum CodingKeys: String, CodingKey {
        case time
        case isDay = "is_day"
    }
}

enum WindDir: String, Codable {
    case ne = "NE"
}

// MARK: - Location
struct Location: Codable {
    let name, region, country: String
    let lat, lon: Double
    let localtime: String
}



struct DaysData {
    let date: String
  //  let temp: Double
}
